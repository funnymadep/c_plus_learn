#!/bin/bash

g++ ./dlogger.cpp -fPIC -shared -o liblog.so